
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yaml


@dataclass
class SegmentMetric:
    name: str
    type: str
    start_time: float
    end_time: float
    duration: float
    entry_speed_mph: float
    min_speed_mph: float
    exit_speed_mph: float
    peak_decel_g: float
    coast_time_s: float
    throttle_pickup_time: Optional[float]
    segment_distance: float
    reference_duration: Optional[float] = None
    time_delta: Optional[float] = None
    reference_min_speed_mph: Optional[float] = None
    min_speed_delta_mph: Optional[float] = None


def parse_time_series(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().mean() > 0.8:
        return numeric - numeric.iloc[0]

    td = pd.to_timedelta(series.astype(str), errors="coerce")
    if td.notna().mean() > 0.8:
        secs = td.dt.total_seconds()
        return secs - secs.iloc[0]

    return pd.Series(np.arange(len(series)) / 10.0)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    lower = {c.lower().strip(): c for c in df.columns}

    def find_any(candidates):
        for cand in candidates:
            for lc, real in lower.items():
                if cand in lc:
                    return real
        return None

    time_col = find_any(["time", "timestamp"])
    dist_col = find_any(["distance"])
    speed_col = find_any(["speed"])
    latg_col = find_any(["lateral", "latacc", "lat acc", "accel y"])
    longg_col = find_any(["longitudinal", "longacc", "long acc", "accel x"])
    throttle_col = find_any(["relative throttle", "throttle position", "throttle"])

    out = pd.DataFrame()

    if time_col is None:
        out["time_s"] = np.arange(len(df)) / 10.0
    else:
        out["time_s"] = parse_time_series(df[time_col])

    if speed_col is None and dist_col is None:
        raise ValueError("Could not find speed or distance columns in CSV.")

    if speed_col is not None:
        out["speed_mph"] = pd.to_numeric(df[speed_col], errors="coerce").interpolate()
    else:
        out["speed_mph"] = np.nan

    if dist_col is not None:
        out["distance"] = pd.to_numeric(df[dist_col], errors="coerce").interpolate()
    else:
        speed_mps = out["speed_mph"] * 0.44704
        dt = out["time_s"].diff().fillna(0).clip(lower=0, upper=1)
        out["distance"] = (speed_mps * dt).cumsum()

    if speed_col is None:
        dt = out["time_s"].diff().replace(0, np.nan)
        dd = out["distance"].diff()
        out["speed_mph"] = (dd / dt * 2.23694).replace([np.inf, -np.inf], np.nan).interpolate()

    out["lat_g"] = pd.to_numeric(df[latg_col], errors="coerce").interpolate() if latg_col else np.nan

    if longg_col:
        out["long_g"] = pd.to_numeric(df[longg_col], errors="coerce").interpolate()
    else:
        speed_mps = out["speed_mph"] * 0.44704
        dt = out["time_s"].diff().replace(0, np.nan)
        out["long_g"] = (speed_mps.diff() / dt / 9.80665).replace([np.inf, -np.inf], np.nan).fillna(0)

    if throttle_col:
        out["throttle"] = pd.to_numeric(df[throttle_col], errors="coerce").interpolate().fillna(0)
    else:
        out["throttle"] = np.nan

    return out.dropna(subset=["time_s", "distance", "speed_mph"]).reset_index(drop=True)


def load_segments(event_dir: Path):
    segments_file = event_dir / "segments.yaml"
    if not segments_file.exists():
        raise FileNotFoundError(f"Missing segments file: {segments_file}")
    return yaml.safe_load(segments_file.read_text())["segments"]


def metrics_for_segment(df: pd.DataFrame, seg: dict) -> Optional[SegmentMetric]:
    part = df[(df["distance"] >= seg["start_distance"]) & (df["distance"] <= seg["end_distance"])].copy()
    if len(part) < 5:
        return None

    n = max(3, len(part) // 10)
    entry = part.iloc[:n]["speed_mph"].mean()
    exit_ = part.iloc[-n:]["speed_mph"].mean()
    min_speed = part["speed_mph"].min()
    peak_decel = part["long_g"].min()

    if part["throttle"].notna().any():
        coast_mask = (part["throttle"] < 5) & (part["long_g"] > -0.10)
    else:
        coast_mask = (part["long_g"] > -0.10) & (part["long_g"] < 0.05)

    dt = part["time_s"].diff().fillna(0).clip(lower=0, upper=1)
    coast_time = float(dt[coast_mask].sum())

    throttle_pickup_time = None
    if part["throttle"].notna().any():
        min_idx = part["speed_mph"].idxmin()
        pickup = part.loc[min_idx:][part.loc[min_idx:]["throttle"] > 20]
        if len(pickup):
            throttle_pickup_time = float(pickup.iloc[0]["time_s"])

    return SegmentMetric(
        name=seg["name"],
        type=seg.get("type", "segment"),
        start_time=float(part.iloc[0]["time_s"]),
        end_time=float(part.iloc[-1]["time_s"]),
        duration=float(part.iloc[-1]["time_s"] - part.iloc[0]["time_s"]),
        entry_speed_mph=float(entry),
        min_speed_mph=float(min_speed),
        exit_speed_mph=float(exit_),
        peak_decel_g=float(peak_decel),
        coast_time_s=coast_time,
        throttle_pickup_time=throttle_pickup_time,
        segment_distance=float(part["distance"].iloc[-1] - part["distance"].iloc[0]),
    )


def analyze(csv_path: Path, event_dir: Path):
    df = normalize_columns(pd.read_csv(csv_path))
    segments = load_segments(event_dir)
    metrics = [m for seg in segments if (m := metrics_for_segment(df, seg))]

    ref_path = event_dir / "reference.csv"
    if ref_path.exists():
        ref_df = normalize_columns(pd.read_csv(ref_path))
        ref_metrics = {m.name: m for seg in segments if (m := metrics_for_segment(ref_df, seg))}
        for m in metrics:
            r = ref_metrics.get(m.name)
            if r:
                m.reference_duration = r.duration
                m.time_delta = m.duration - r.duration
                m.reference_min_speed_mph = r.min_speed_mph
                m.min_speed_delta_mph = m.min_speed_mph - r.min_speed_mph

    findings = build_findings(metrics)
    return df, metrics, findings


def build_findings(metrics: list[SegmentMetric]):
    findings = []
    for m in metrics:
        score = 0.0
        reasons = []

        if m.coast_time_s > 0.45:
            score += min(3, m.coast_time_s * 2)
            reasons.append(f"coasted {m.coast_time_s:.2f}s")

        if m.peak_decel_g > -0.55 and m.type in {"hairpin", "turnaround", "sweeper"}:
            score += 1.5
            reasons.append(f"peak braking only {m.peak_decel_g:.2f}G")

        if m.min_speed_delta_mph is not None and m.min_speed_delta_mph < -3:
            score += abs(m.min_speed_delta_mph) * 0.4
            reasons.append(f"minimum speed {abs(m.min_speed_delta_mph):.1f} mph below reference")

        if m.time_delta is not None and m.time_delta > 0.15:
            score += m.time_delta * 4
            reasons.append(f"{m.time_delta:.2f}s slower than reference")

        if score > 0:
            findings.append({
                "score": score,
                "segment": m,
                "reasons": reasons,
                "coaching": coach_text(m),
            })

    return sorted(findings, key=lambda x: x["score"], reverse=True)


def coach_text(m: SegmentMetric) -> str:
    t = fmt_time(m.start_time)

    if m.type in {"hairpin", "turnaround"}:
        return (
            f"For the {m.name} at {t}, prioritize a cleaner V-shaped rotation: "
            f"brake later with a firmer initial hit, get the car turned, then unwind and accelerate sooner."
        )

    if m.type == "sweeper":
        return (
            f"In the {m.name} at {t}, protect momentum. "
            f"Avoid over-slowing; use one decisive brake/lift, then carry speed with earlier maintenance throttle."
        )

    if m.type == "slalom":
        return f"In the {m.name} at {t}, commit earlier to the first cone and reduce hesitation between transitions."

    if m.type == "finish":
        return f"In the {m.name} at {t}, stay committed and avoid unnecessary lift before timing."

    return f"At {m.name} around {t}, reduce hesitation and prioritize earlier throttle commitment."


def fmt_time(seconds: float) -> str:
    minutes = int(seconds // 60)
    sec = seconds - 60 * minutes
    return f"{minutes:02d}:{sec:06.3f}"


def write_report(csv_path: Path, metrics: list[SegmentMetric], findings: list[dict], reports_dir: Path):
    reports_dir.mkdir(parents=True, exist_ok=True)
    stem = csv_path.stem
    md_path = reports_dir / f"{stem}_report.md"
    json_path = reports_dir / f"{stem}_summary.json"

    lines = [f"# RaceCoach Report — {csv_path.name}", "", "## Top 3 Opportunities", ""]

    if not findings:
        lines.append("No high-confidence opportunities detected. Check segment definitions and reference run.")
    else:
        for i, f in enumerate(findings[:3], start=1):
            m = f["segment"]
            lines += [
                f"### {i}. {m.name} — {fmt_time(m.start_time)}",
                "",
                f["coaching"],
                "",
                "**Telemetry:**",
                f"- Entry speed: {m.entry_speed_mph:.1f} mph",
                f"- Minimum speed: {m.min_speed_mph:.1f} mph",
                f"- Exit speed: {m.exit_speed_mph:.1f} mph",
                f"- Peak braking/decel: {m.peak_decel_g:.2f} G",
                f"- Coast time: {m.coast_time_s:.2f} sec",
            ]
            if m.reference_min_speed_mph is not None:
                lines.append(f"- Reference min speed: {m.reference_min_speed_mph:.1f} mph")
            if m.time_delta is not None:
                lines.append(f"- Segment delta vs reference: {m.time_delta:+.2f} sec")
            lines.append(f"- Why flagged: {', '.join(f['reasons'])}")
            lines.append("")

    lines += [
        "",
        "## Segment Table",
        "",
        "| Segment | Type | Start | Duration | Entry | Min | Exit | Peak Decel | Coast | Delta |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]

    for m in metrics:
        delta = "" if m.time_delta is None else f"{m.time_delta:+.2f}"
        lines.append(
            f"| {m.name} | {m.type} | {fmt_time(m.start_time)} | {m.duration:.2f} | "
            f"{m.entry_speed_mph:.1f} | {m.min_speed_mph:.1f} | {m.exit_speed_mph:.1f} | "
            f"{m.peak_decel_g:.2f} | {m.coast_time_s:.2f} | {delta} |"
        )

    md_path.write_text("\n".join(lines))

    summary = {
        "source": csv_path.name,
        "metrics": [asdict(m) for m in metrics],
        "findings": [
            {
                "score": f["score"],
                "segment": f["segment"].name,
                "reasons": f["reasons"],
                "coaching": f["coaching"],
            }
            for f in findings
        ],
    }
    json_path.write_text(json.dumps(summary, indent=2))
    return md_path, json_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", type=Path)
    parser.add_argument("--event", type=Path, required=True)
    parser.add_argument("--reports", type=Path, default=Path("reports"))
    args = parser.parse_args()

    _, metrics, findings = analyze(args.csv, args.event)
    md, js = write_report(args.csv, metrics, findings, args.reports)
    print(md.read_text())
    print(f"\nWrote: {md}")
    print(f"Wrote: {js}")


if __name__ == "__main__":
    main()
